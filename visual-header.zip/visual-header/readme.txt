﻿=== Visual Header ===
Contributors: dastan-web
Tags: header creator, header builder
Tested up to: 6.2
Requires PHP: 7.4.0
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Header Builder for WordPress 

== Description ==
You can builder Header and allows you to display a group of mixed content in a responsive and compatible Header.
 

== Installation ==

This section describes how to install the plugin and get it working.
 

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Settings->Plugin Name screen to configure the plugin
4. go the edit or create page and switch sor page builder


== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.
 

== Changelog ==

= 1.0 =
* A change since the previous version.
* Another change.

= 1.0 =
* List versions from most recent at top to oldest at bottom.

== Upgrade Notice ==

= 1.0 =
Upgrade notices describe the reason a user should upgrade.  No more than 300 characters.

= 1.0 =
This version fixes a security related bug.  Upgrade immediately.


